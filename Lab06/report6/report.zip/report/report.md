---
# Front matter
lang: ru-RU
title: "Отчёт по лабораторной работе №6"
subtitle: "дисциплина: Информационная безопасность"
author: "Фогилева ксения Михайловна"

# Formatting
toc-title: "Содержание"
toc: true # Table of contents
toc_depth: 2
lof: true # List of figures
lot: true # List of tables
fontsize: 12pt
linestretch: 1.5
papersize: a4paper
documentclass: scrreprt
polyglossia-lang: russian
polyglossia-otherlangs: english
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase
indent: true
pdf-engine: lualatex
header-includes:
  - \linepenalty=10 # the penalty added to the badness of each line within a paragraph (no associated penalty node) Increasing the value makes tex try to have fewer lines in the paragraph.
  - \interlinepenalty=0 # value of the penalty (node) added after each line of a paragraph.
  - \hyphenpenalty=50 # the penalty for line breaking at an automatically inserted hyphen
  - \exhyphenpenalty=50 # the penalty for line breaking at an explicit hyphen
  - \binoppenalty=700 # the penalty for breaking a line at a binary operator
  - \relpenalty=500 # the penalty for breaking a line at a relation
  - \clubpenalty=150 # extra penalty for breaking after first line of a paragraph
  - \widowpenalty=150 # extra penalty for breaking before last line of a paragraph
  - \displaywidowpenalty=50 # extra penalty for breaking before last line before a display math
  - \brokenpenalty=100 # extra penalty for page breaking after a hyphenated line
  - \predisplaypenalty=10000 # penalty for breaking before a display
  - \postdisplaypenalty=0 # penalty for breaking after a display
  - \floatingpenalty = 20000 # penalty for splitting an insertion (can only be split footnote in standard LaTeX)
  - \raggedbottom # or \flushbottom
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы

Развить навыки администрирования ОС Linux. Получить первое практическое знакомство с технологией SELinux. Проверить работу SELinx на практике совместно с веб-сервером Apache.

# Теоретическое описание

SELinux — набор технологий расширения системы безопасности Linux. Сегодня основу набора составляют три технологии: мандатный контроль доступа, ролевой доступ RBAC и система типов (доменов). Apache – это свободное программное обеспечение для размещения веб-сервера. Он хорошо показывает себя в работе с масштабными проектами, поэтому заслуженно считается одним из самых популярных веб-серверов. Кроме того, Apache очень гибок в плане настройки, что даёт возможность реализовать все особенности размещаемого веб-ресурса.

# Выполнение лабораторной работы

1. Вошла в систему с полученными учётными данными и убедилась, что SELinux работает в режиме enforcing политики targeted с помощью команд getenforce и sestatus.(рис. -@fig:001). 

![Проверка](image/1.jpg){ #fig:001 width=70% }

2. Обратилась с помощью браузера к веб-серверу, запущенному на компьютере, и убедилась, что последний работает: service httpd status(рис. -@fig:002).

![Проверка](image/2.jpg){ #fig:002 width=70% }

3. Нашла веб-сервер Apache в списке процессов, определила его контекст безопасности. (рис. -@fig:003). 

![веб-сервер Apache](image/3.jpg){ #fig:003 width=70%}

4. Посмотрела текущее состояние переключателей SELinux для Apache с помощью команды: sestatus -bigrep httpd. Обратила внимание, что многие из них находятся в положении «off». (рис. -@fig:004). 

![Просмотр состояние переключателей SELinux для Apache](image/4.jpg){ #fig:004 width=70% }

5. Посмотрела статистику по политике с помощью команды seinfo, также определила множество пользователей(8), ролей(14), типов(4793). Определила тип файлов и поддиректорий, находящихся в директории /var/www, с помощью команды: ls -lZ /var/www. Определила тип файлов, находящихся в директории /var/www/html: ls -lZ /var/www/html. Определила круг пользователей, которым разрешено создание файлов в директории /var/www/html. (рис. -@fig:005). 

![Получение информации](image/5.jpg){ #fig:005 width=70% }

6. Создала от имени суперпользователя (так как в дистрибутиве после установки только ему разрешена запись в директорию) html-файл /var/www/html/test.html(рис. -@fig:006). 

![Создание файла](image/6.jpg){ #fig:006 width=70% }

7. Проверила контекст созданного файла. httpd_sys_content_t (рис. -@fig:007). 

![Проверка](image/7.jpg){ #fig:007 width=70% }

8. Обратилась к файлу через веб-сервер, введя в браузере адрес http://127.0.0.1/test.html. Убедилась, что файл был успешно отображён. (рис. -@fig:008). 

![Получение доступа к файлу через браузер](image/8.jpg){ #fig:008 width=70% }

9. Проверила контекст файла командой: ls -Z /var/www/html/test.html (рис. -@fig:009). 

![Проверка контекста](image/9.jpg){ #fig:009 width=70% }

10. Изменила контекст файла /var/www/html/test.html с httpd_sys_content_t на samba_share_t. После этого проверила, что контекст поменялся. (рис. -@fig:010). 

![Изменение контекста, проверка](image/10.jpg){ #fig:010 width=70% }

11. Попробовала ещё раз получить доступ к файлу через веб-сервер, введя в
браузере адрес http://127.0.0.1/test.html. Получили сообщение об ошибке. (рис. -@fig:011).

![Получение доступа к файлу через браузер](image/11.jpg){ #fig:011 width=70% }

12. Проанализировала ситуацию. Файл не был отображён потому что мы изменили контекст файла. Просмотрела log-файлы веб-сервера Apache. Также просмотрела системный лог-файл: tail /var/log/messages (рис. -@fig:012), (рис. -@fig:013). 

![Проверка](image/12.jpg){ #fig:012 width=70% }

![Просмотр системного лог-файла](image/13.jpg){ #fig:013 width=70% }

13. Попробовала запустить веб-сервер Apache на прослушивание ТСР-порта 81 (а не 80, как рекомендует IANA и прописано в /etc/services). Для этого в файле /etc/httpd/httpd.conf нашла строчку Listen 80 и замените её на Listen 81.(рис. -@fig:014). 

![Изменеие порта 80 на 81](image/14.jpg){ #fig:014 width=70% }

14. Проанализиировала лог-файлы. Просмотрела файлы /var/log/http/error_log, /var/log/http/access_log и /var/log/audit/audit.log. (рис. -@fig:015), (рис. -@fig:016), (рис. -@fig:017), (рис. -@fig:018).

![Анализ лог-файла](image/15.jpg){ #fig:015 width=70% }

![Просмотр файла /var/log/http/access_log](image/16.jpg){ #fig:016 width=70% }

![Просмотр файла /var/log/http/error_log](image/17.jpg){ #fig:017 width=70% }

![Просмотр файла var/log/audit/audit.log](image/18.jpg){ #fig:018 width=70% }

15. Выполнила команду: semanage port -a -t http_port_t -р tcp 81. После этого проверила список портов командой: semanage port -l | grep http_port_t. Убедилась, что порт 81 появился в списке. (рис. -@fig:019).

![Выполнение и проверка](image/19.jpg){ #fig:019 width=70% }

16. Вернула контекст httpd_sys_cоntent__t к файлу /var/www/html/test.html: chcon -t httpd_sys_content_t /var/www/html/test.html. После этого попробовала получить доступ к файлу через веб-сервер, введя в браузере адрес http://127.0.0.1:81/test.html. Увидели содержимое файла — слово «test». (рис. -@fig:020), (рис. -@fig:021).

![Возвращение контекста](image/20.jpg){ #fig:020 width=70% }

![Получение доступа к файлу через браузер](image/21.jpg){ #fig:021 width=70% }

17. Исправила обратно конфигурационный файл apache, вернувListen80. (рис. -@fig:022).

![Исправление конфигурационного файл apache](image/22.jpg){ #fig:022 width=70% }

18. Удалила привязку http_port_t к 81 порту. (рис. -@fig:023).

![Удалние привязки http_port_t к 81 порту](image/23.jpg){ #fig:023 width=70% }

19. Удалила файл /var/www/html/test.html. (рис. -@fig:024).

![Удаление файла /var/www/html/test.html](image/24.jpg){ #fig:024 width=70% }


# Выводы
На основе проделанной работы развила навыки администрирования ОС Linux. Получила первое практическое знакомство с технологией SELinux. Проверила работу SELinx на практике совместно с веб-сервером Apache.